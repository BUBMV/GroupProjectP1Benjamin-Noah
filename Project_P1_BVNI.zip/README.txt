SLCM Intake Data Project

This project uses intake and household data to explore housing risk, employment and income, household composition, repeat contact, and data quality. Both notebooks run in Google Colab.

Files:
- SLCM_Task1_Urgency_Duration(3)(2).ipynb: Groups tickets by urgency and episodic or chronic need, then displays a table and chart.
- SLCM_Part2_Needed_Only_Commented(2)(2).ipynb: Uses Needed columns to explore the five project questions and document data cleaning.
- cleaned_intakes_masked(7).csv: Main intake data.
- household_members_long_v2(1).csv: Additional household member data.
- SLCM_93_column_triage(1).csv: Column classifications and reasons. Required for Part 2.

How to run:
- Create a folder in Google Drive at My Drive/Colab Notebooks/Data Project 1.
- Upload the three CSVs to that folder. Rename them to cleaned_intakes_masked.csv, household_members_long_v2.csv, and SLCM_93_column_triage.csv.
- Open the notebooks in Google Colab at https://colab.research.google.com/.
- In Task 1, move the Google Drive mount cell above the cell that loads the CSVs. Part 2 already has it in the correct order.
- Run the mount cell and approve access to Google Drive.
- Run the remaining cells from top to bottom. Review Task 1 first, then Part 2. Each notebook loads its own data.
- If you use a different folder or filenames, update the pd.read_csv paths in both notebooks.

Results appear below the cells as tables, charts, and summaries. Save the notebooks after running them to keep the outputs. The notebooks do not automatically export separate result files.

If a file cannot be found, check the filenames, folder location, and Drive connection. The notebooks use pandas, NumPy, Matplotlib, and Seaborn. If a package is missing, run this in a new Colab cell:

%pip install pandas numpy matplotlib seaborn

If you get an unexpected keyword error for tick_labels or include_groups, run the following, restart the session, and rerun the notebook:

%pip install --upgrade matplotlib pandas

The urgency and chronic/episodic groups are estimates. Repeat tickets do not prove chronic need, and being labeled less urgent does not guarantee stable housing.
